// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "DodgeballGameMode.generated.h"

UCLASS(minimalapi)
class ADodgeballGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	ADodgeballGameMode();
};



