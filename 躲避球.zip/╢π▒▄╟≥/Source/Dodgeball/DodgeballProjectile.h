// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "DodgeballProjectile.generated.h"

UCLASS()
class DODGEBALL_API ADodgeballProjectile : public ACharacter
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = DodgeBall, meta = (AllowPrivateAccess = "true"))
	class USphereComponent* SphereComponent;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = DodgeBall, meta = (AllowPrivateAccess = "true"))
	class UProjectileMovementComponent* ProjectileMovement;
	UPROPERTY(EditAnywhere, Category = Damage)
	float Damage = 34.f;
	UPROPERTY(EditAnywhere, Category = Particles)
	class UParticleSystem *HitParticles;
public:
	FORCEINLINE class UProjectileMovementComponent* GetProjectileMovementComponent() const {
		return ProjectileMovement;
	}

public:
	// Sets default values for this character's properties
	ADodgeballProjectile();
	UFUNCTION()
	void OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
