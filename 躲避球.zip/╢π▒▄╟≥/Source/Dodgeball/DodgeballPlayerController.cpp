// Fill out your copyright notice in the Description page of Project Settings.


#include "DodgeballPlayerController.h"

#include "RestartWidget.h"
#include "HUDWidget.h"

void ADodgeballPlayerController::ShowRestartWidget() {
	if (BP_RestartWidget == nullptr) {
		return;
	}
	SetPause(true);
	SetInputMode(FInputModeUIOnly());
	bShowMouseCursor = true;
	RestartWidget = CreateWidget<URestartWidget>(this, BP_RestartWidget);
	RestartWidget->AddToViewport();
}

void ADodgeballPlayerController::HideRestartWidget() {
	if (BP_RestartWidget == nullptr) {
		return;
	}
	RestartWidget->RemoveFromParent();
	RestartWidget->Destruct();
	SetPause(false);
	SetInputMode(FInputModeGameOnly());
	bShowMouseCursor = false;
}

void ADodgeballPlayerController::UpdateHealthPercent(float HealthPercent)
{
	if (HUDWidget != nullptr) {
		HUDWidget->UpdateHealthPercent(HealthPercent);
	}
}

void ADodgeballPlayerController::BeginPlay() {
	Super::BeginPlay();
	if (BP_HUDWidget == nullptr) {
		return;
	}
	HUDWidget = CreateWidget<UHUDWidget>(this, BP_HUDWidget);
	HUDWidget->AddToViewport();
}
