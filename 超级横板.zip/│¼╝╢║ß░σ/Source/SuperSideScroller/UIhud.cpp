// Fill out your copyright notice in the Description page of Project Settings.


#include "UIhud.h"
#include <Components/TextBlock.h>
#include "Kismet/KismetStringLibrary.h"

void UUIhud::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	SetCoinString(0);
}

void UUIhud::SetCoinString(int32 num) {
	if (ShowCoin != nullptr) {
		FString Text = FString::Printf(TEXT("coin:%d "), num);
		ShowCoin->SetText(FText::FromString(Text));
	}
}
