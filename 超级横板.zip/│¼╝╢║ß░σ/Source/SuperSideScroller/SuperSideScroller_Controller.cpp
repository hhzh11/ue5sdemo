// Fill out your copyright notice in the Description page of Project Settings.


#include "SuperSideScroller_Controller.h"
#include "UIhud.h"


void ASuperSideScroller_Controller::BeginPlay() {
	Super::BeginPlay();
	if (BP_HUDWidget == nullptr) {
		return;
	}
	if (!IsLocalController()) {
		return;
	}
	HUDWidget = CreateWidget<UUIhud>(this, BP_HUDWidget);
	HUDWidget->AddToViewport();
}

void ASuperSideScroller_Controller::UpdateCoin(int32 coin)
{
	if (!IsLocalController()) {
		return;
	}
	if (HUDWidget != nullptr) {
		HUDWidget->SetCoinString(coin);
	}
}