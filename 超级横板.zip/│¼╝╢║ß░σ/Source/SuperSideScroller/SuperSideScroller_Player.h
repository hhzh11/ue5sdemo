// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "SuperSideScrollerCharacter.h"
#include "PlayerProjectile.h"
#include "SuperSideScroller_Player.generated.h"

/**
 * 
 */
UCLASS()
class SUPERSIDESCROLLER_API ASuperSideScroller_Player : public ASuperSideScrollerCharacter
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = Input)
	UInputMappingContext* IC_Character;

	UPROPERTY(EditAnywhere, Category = Input)
	UInputAction* IA_Sprint;

	UPROPERTY(EditAnywhere, Category = Input)
	UInputAction* IA_Throw;

	UPROPERTY(EditAnywhere)
	UAnimMontage* ThrowMontage;

	UPROPERTY(EditAnywhere)
	TSubclassOf<APlayerProjectile> PlayerProjectile;
public:
	ASuperSideScroller_Player();
	void SpawnProjectile();
	UFUNCTION(BlueprintPure)
	int32 GetCurrentNumberofCollectables() {
		return NumberofCollectables;
	}
	void IncrementNumberofCollectables(int32 value);
	void IncreaseMovementPowerUp();
	virtual void BeginPlay() override;
protected:
	// APawn interface
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	void Sprint();
	void StopSprint();
	void ThrowProjectile();
	void EndPowerUp();
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "FPS Character")
	int32 NumberofCollectables;
private:
	bool bIsSprinting;
	FTimerHandle PowerupHandle;
	bool bHasPowerupActive;
};
