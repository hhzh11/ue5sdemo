// Fill out your copyright notice in the Description page of Project Settings.


#include "SuperSideScroller_Player.h"
#include "Components/InputComponent.h"
#include "GameFrameWork/CharacterMovementComponent.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "Animation/AnimInstance.h"
#include "Engine/World.h"
#include "Components/SphereComponent.h"
#include "SuperSideScroller_Controller.h"
#include "Net/UnrealNetwork.h"

ASuperSideScroller_Player::ASuperSideScroller_Player() {
	bIsSprinting = false;
	GetCharacterMovement()->MaxWalkSpeed = 300.0f;
}
void ASuperSideScroller_Player::BeginPlay() {
	
	Super::BeginPlay();
	if (!HasAuthority())
	{
		return;
	}
	NumberofCollectables = 0;
}
void ASuperSideScroller_Player::IncrementNumberofCollectables(int32 value)
{
	if (value == 0) {
		return;
	}
	NumberofCollectables += value;
	ASuperSideScroller_Controller* PlayerController = Cast<ASuperSideScroller_Controller>(GetController());
	if (PlayerController != nullptr) {
		PlayerController->UpdateCoin(NumberofCollectables);
	}
}
void ASuperSideScroller_Player::IncreaseMovementPowerUp()
{
	bHasPowerupActive = true;
	GetCharacterMovement()->MaxWalkSpeed = 500.0f;
	GetCharacterMovement()->JumpZVelocity = 1500.0f;
	UWorld* World = GetWorld();
	if (World) {
		World->GetTimerManager().SetTimer(PowerupHandle, this, &ASuperSideScroller_Player::EndPowerUp, 8.0f, false);
	}
}

void ASuperSideScroller_Player::GetLifetimeReplicatedProps(TArray<FLifetimeProperty >& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME_CONDITION(ASuperSideScroller_Player, NumberofCollectables, COND_OwnerOnly);
}

void ASuperSideScroller_Player::EndPowerUp()
{
	bHasPowerupActive = false;
	GetCharacterMovement()->MaxWalkSpeed = 300.0f;
	GetCharacterMovement()->JumpZVelocity = 1000.0f;
	UWorld* World = GetWorld();
	if (World) {
		World->GetTimerManager().ClearTimer(PowerupHandle);
	}
}

void ASuperSideScroller_Player::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) {
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (EnhancedInputComponent) {
		APlayerController* PlayerController = Cast<APlayerController>(GetController());
		UEnhancedInputLocalPlayerSubsystem* EnhancedSubsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer());
		if (EnhancedSubsystem) {
			EnhancedSubsystem->AddMappingContext(IC_Character, 1);
		}
		EnhancedInputComponent->BindAction(IA_Sprint, ETriggerEvent::Triggered, this, &ASuperSideScroller_Player::Sprint);
		EnhancedInputComponent->BindAction(IA_Sprint, ETriggerEvent::Completed, this, &ASuperSideScroller_Player::StopSprint);
		EnhancedInputComponent->BindAction(IA_Throw, ETriggerEvent::Completed, this, &ASuperSideScroller_Player::ThrowProjectile);
	}
}

void ASuperSideScroller_Player::Sprint() {
	if (!bIsSprinting) {
		bIsSprinting = true;
		if (bHasPowerupActive) {
			GetCharacterMovement()->MaxWalkSpeed = 900.0f;
		}
		else {
			GetCharacterMovement()->MaxWalkSpeed = 500.0f;
		}
	}
}

void ASuperSideScroller_Player::StopSprint() {
	if (bIsSprinting) {
		bIsSprinting = false;
		if (bHasPowerupActive) {
			GetCharacterMovement()->MaxWalkSpeed = 500.0f;
		}
		else {
			GetCharacterMovement()->MaxWalkSpeed = 300.0f;
		}
	}
}

void ASuperSideScroller_Player::ThrowProjectile() {
	if (ThrowMontage) {
		const bool bIsMontagePlaying = GetMesh()->GetAnimInstance()->Montage_IsPlaying(ThrowMontage);
		if (!bIsMontagePlaying) {
			GetMesh()->GetAnimInstance()->Montage_Play(ThrowMontage, 1.0f);
		}
	}
}

void ASuperSideScroller_Player::SpawnProjectile()
{
	if (PlayerProjectile) {
		UWorld* World = GetWorld();
		if (World) {
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			const FVector SpawnLocation = this->GetMesh()->GetSocketLocation(FName("ProjectileSocket"));
			const FRotator Rotation = GetActorForwardVector().Rotation();
			APlayerProjectile* Projectile = World->SpawnActor<APlayerProjectile>(PlayerProjectile, SpawnLocation, Rotation, SpawnParams);
		}
	}
}
